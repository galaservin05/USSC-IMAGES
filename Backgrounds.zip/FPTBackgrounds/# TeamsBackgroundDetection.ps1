# Path to the Teams custom backgrounds folder
$backgroundFolder = "$($env:LOCALAPPDATA)\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams\Backgrounds\Uploads"

# Get all images that should be in the folder
$backgrounds = Get-ChildItem "C:\temp\FPTBackgrounds\UUID Converted Images"

# All image and thumbnail names to compare
$expectedImages = @( 
    "0d96d553-2e2d-47a8-bdae-cbdf2e5e6ee2.png", 
    "0d96d553-2e2d-47a8-bdae-cbdf2e5e6ee2_thumb.png", 
    "1517471f-9740-4e39-a3d8-c249c991c069.png", 
    "1517471f-9740-4e39-a3d8-c249c991c069_thumb.png", 
    "223b0209-6bfc-4b45-b5be-6cda99b30921.png", 
    "223b0209-6bfc-4b45-b5be-6cda99b30921_thumb.png", 
    "68444f66-53b0-4a3d-83f8-d835e646a0fc.png", 
    "68444f66-53b0-4a3d-83f8-d835e646a0fc_thumb.png"
)

# Get all image files in the background folder
$backgroundFolderImages = Get-ChildItem -Path $backgroundFolder -File | Select-Object -ExpandProperty Name

# Compare the expected images with the actual images in the folder
$missingImages = $expectedImages | Where-Object { $_ -notin $backgroundFolderImages }

# Check if all expected images are present
if ($missingImages.Count -eq 0) {
    Write-Host "All expected images are present."
    $allImagesPresent = $true
} else {
    Write-Host "The following images are missing:"
    $missingImages | ForEach-Object { Write-Host $_ }
    $allImagesPresent = $false
}

# Output the result to a log file if necessary
if (-not $allImagesPresent) {
    $missingImages | Out-File "C:\temp\FPTBackgrounds\MissingImagesLog.txt"
}