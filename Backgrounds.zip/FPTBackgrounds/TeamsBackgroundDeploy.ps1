# Path to the Teams custom backgrounds folder
$backgroundFolder = "$($env:LOCALAPPDATA)\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams\Backgrounds\Uploads"

# Get all images that should be in the folder
$backgrounds = Get-ChildItem "C:\temp\FPTBackgrounds\UUID Converted Images"

# Ensure the Teams background folder exists
if (!(Test-Path -Path $backgroundFolder)) {
    # Backgrounds\Uploads doesn't exist, attempting to create it...
    try {
        New-Item -Path $backgroundFolder -ItemType Directory
        Write-Host "Successfully created $($backgroundFolder)" -f green
    } catch {
        Write-Host "Failed to create $($backgroundFolder)" -f red
    }
} else {
    Write-Host "$($backgroundFolder) already exists, moving to next step." -f blue
}

# Copy each image to the Teams background folder
foreach ($background in $backgrounds) {
    $imageSource = $background.FullName  # Correct source path
    $imageName = $background.Name        # File name
    
    # Attempt to copy the image from source to destination
    try {
        Copy-Item -Path $imageSource -Destination $backgroundFolder -Force
        Write-Host "Image $($imageName) successfully copied to Teams background folder." -f green
    } catch {
        Write-Host "Failed to copy $($imageName)." -f red
    } 
}
